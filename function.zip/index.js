// Getting All Items From DynamoDB Table

import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";

const Region="us-east-1"; // Replace with your AWS region
const TableName="BraceletReadings"; // Replace with your DynamoDB table name

const dbClient = new DynamoDBClient({ region: Region });

export const handler = async (event) => {
    try {
        const params = {
            TableName: TableName,
        };

        const command = new ScanCommand(params);
        const data = await dbClient.send(command);

        return {
            statusCode: 200,
            body: JSON.stringify(data.Items),
        };
    } catch (err) {
        console.error("Error", err);
        return {

            statusCode: 500,
            body: JSON.stringify({ error: "Could not retrieve items" }),
        };
    }

};


// Test Locally

handler().then(response => {
    console.log("Response:", response);
}).catch(error => {
    console.error("Error:", error);
});

